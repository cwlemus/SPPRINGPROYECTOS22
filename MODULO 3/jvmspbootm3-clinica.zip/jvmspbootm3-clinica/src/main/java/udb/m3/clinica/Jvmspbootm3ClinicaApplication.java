package udb.m3.clinica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jvmspbootm3ClinicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Jvmspbootm3ClinicaApplication.class, args);
	}

}
