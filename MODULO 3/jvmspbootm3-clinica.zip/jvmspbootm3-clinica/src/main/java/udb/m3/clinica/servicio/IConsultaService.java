package udb.m3.clinica.servicio;

import udb.m3.clinica.modelo.Consulta;

public interface IConsultaService extends ICRUD<Consulta> {

}
