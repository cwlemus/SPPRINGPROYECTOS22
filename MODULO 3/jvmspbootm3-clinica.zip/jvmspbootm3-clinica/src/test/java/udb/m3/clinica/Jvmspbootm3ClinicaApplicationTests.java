package udb.m3.clinica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jvmspbootm3ClinicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
