export interface Medico {
    idMedico:       number;
    nombreMedico:   string;
    apellidoMedico: string;
    jvpm:           string;
}
